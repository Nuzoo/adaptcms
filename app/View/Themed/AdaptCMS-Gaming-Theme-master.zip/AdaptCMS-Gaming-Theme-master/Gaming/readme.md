# Gaming

One of the starter themes, this gaming theme allows webmasters to get their gaming website up very quickly. Included are categories, fields, templates and a few basic articles.

## Installation

The Gaming theme is included, but if you delete it manually, then read below:

To install, first download the zip and unpack the folder 'Gaming' into your 'app/View/Old_Themed' folder - be sure to chmod this new folder to 755. Then login into your admin panel and click on 'Appearance'. You should see this theme listed and an option to install on the right side.
Simply click that and click continue on the install and everything should be done!

### More Resources

Check out the official [API Page](http://api.adaptcms.com/theme/gaming).